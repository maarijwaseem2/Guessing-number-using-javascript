'use strict'
let secretnumber = Math.trunc(Math.random() * 20) + 1;
document.querySelector('.number').textContent = secretnumber;
let highscore = 0;
let score = 20;

const displaymessage = function(message){
    document.querySelector('.message').textContent = message;
}

document.querySelector(".number").textContent = '?';
document.querySelector('.check').addEventListener('click', function () {
    const Guess = Number(document.querySelector('.guess').value);
    console.log(Guess, typeof Guess);

    if (!Guess) {
        // document.querySelector('.message').textContent = 'No number';
        displaymessage('No Number');
    } 
    else if (Guess === secretnumber) {
        // document.querySelector('.message').textContent = '🎉Correct Number!';
        displaymessage('🎉Correct Number!');
        document.querySelector(".number").textContent = secretnumber;

        document.querySelector('body').style.backgroundColor = '#60b347';
        if(score > highscore){
            highscore=score;
            document.querySelector('.highscore').textContent = highscore;
        }
    }
    else if(Guess !==secretnumber){
        if (score > 1) {
            // document.querySelector('.message').textContent = Guess>secretnumber ? '⏫ Too High!' : '⏬ Too Low!';
            displaymessage(Guess>secretnumber ? '⏫ Too High!' : '⏬ Too Low!');
            score--;
            document.querySelector('.score').textContent = score;
        }
        else {
            // document.querySelector('.message').textContent = '💥You Lost the game';
            displaymessage('💥You Lost the game');
            document.querySelector('.score').textContent = 0;
        }
    }
//     else if (Guess > secretnumber) {
//         if (score > 1) {
//             document.querySelector('.message').textContent = '⏫ Too High!';
//             score--;
//             document.querySelector('.score').textContent = score;
//         }
//         else {
//             document.querySelector('.message').textContent = '💥You are Lost the game';
//             document.querySelector('.score').textContent = 0;
//         }
//     } 
//     else if (Guess < secretnumber) {
//         if (score > 1) {
//             document.querySelector('.message').textContent = '⏬ Too Low!';
//             score--;
//             document.querySelector('.score').textContent = score;
//         } 
//         else {
//             document.querySelector('.message').textContent = '💥 You are Lost the game';
//             document.querySelector('.score').textContent = 0;
//         }
//     }
});

const againButton = document.querySelector('.again').addEventListener('click',function(){
    score = 20;
    secretnumber = Math.trunc(Math.random() * 20) + 1;
    displaymessage('Start guessing...');
    document.querySelector('.number').textContent = '?';
    document.querySelector('.score').textContent = score;
    document.querySelector('.guess').value = '';

    document.querySelector('body').style.backgroundColor = '#222';
});
